function openName (name) {
    alert(name);
}