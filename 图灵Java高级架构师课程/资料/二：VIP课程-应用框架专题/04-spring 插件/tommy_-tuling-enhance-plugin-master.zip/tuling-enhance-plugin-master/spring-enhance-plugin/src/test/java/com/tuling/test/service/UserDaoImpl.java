package com.tuling.test.service;

public class UserDaoImpl implements UserDao {
	public UserDaoImpl() {
		System.out.println("创建 UserDaoImpl");
	}
}
